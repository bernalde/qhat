"""Generate both predeclared main inputs once under their frozen phase pool."""
import hashlib,json,sys
from pathlib import Path
planpath=Path(sys.argv[1]).resolve();plan=json.loads(planpath.read_text());source=Path(plan['producer_root'])
sys.path.insert(0,str(source/'numerical_audit/molecular_generalization'))
import common as k
import runner
import generate_inputs
k.require(k.sha(Path(__file__))==plan['operator_sha256'],'Exact input dispatch operator')
data=Path(plan['data_root']);h,config=k.header(data,producer=True)
k.require(h['mode']=='main' and k.frozen(data)['source_commit']==plan['source_commit'],'Frozen prospective main identity')
k.require(not(data/'INPUTS_FROZEN.json').exists(),'One fixed input finalization')
cpu,wall=config['main_per_case_dispatch']['input'];k.require([cpu,wall]==plan['per_case_CPU_wall'],'Frozen input allowances')
rows=[]
for case in h['cases']:
    label='mg-input-'+case.lower().replace('_','-')
    command=[sys.executable,str(k.HERE/'generate_inputs.py'),'--data',str(data),'--case',case]
    jp,rp=runner.dispatch(data,label,'inputs',command,cpu,wall,512,identity=dict(case=case),expected_raw='inputs/'+case+'/model.json')
    receipt=k.read(rp);rows.append(dict(case=case,receipt=str(rp.relative_to(data)),exit_code=receipt['exit_code'],termination=receipt.get('termination')))
    print('MAIN_INPUT_ATTEMPT_CLOSED',case,receipt['exit_code'],flush=True)
complete=generate_inputs.finalize(data)
k.write_new(data/'preparation/INPUT_DISPATCH_RESULT.json',dict(rows=rows,complete=complete,no_training_or_physical_errors_executed=True))
k.require(complete and all(row['exit_code']==0 and row['termination']is None for row in rows),'Input refusal retained; do not proceed to constructors or physics')
print('BOTH_PROSPECTIVE_MAIN_INPUTS_AUTHENTICATED',flush=True)
