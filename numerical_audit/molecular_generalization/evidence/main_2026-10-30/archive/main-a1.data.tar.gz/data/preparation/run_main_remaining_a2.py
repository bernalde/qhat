"""Run only unattempted main phases after an authenticated native raw censor.

Original constructor orders, scores, costs, reports and frozen scientific gates
are unchanged. The incomplete objective/primary verdict is retained verbatim.
This continuation completes the planned physical evidence, not a primary gate.
"""
import json
from pathlib import Path
import subprocess
import sys
import tomllib

planpath = Path(sys.argv[1]).resolve()
plan = json.loads(planpath.read_text())
source, data = Path(plan['producer_root']), Path(plan['data_root'])
sys.path.insert(0, str(source/'numerical_audit/molecular_generalization'))
import common as k
import runner

k.require(k.sha(Path(__file__)) == plan['operator_sha256'], 'Exact continuation source')
k.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
          == plan['source_commit'] and
          not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True),
          'Keep original frozen producer HEAD clean')
h, config = k.header(data, producer=True)
k.require(h['mode'] == 'main' and k.sha(data/'INPUT_PROTOCOL_FROZEN.json') == plan['source_freeze_sha256']
          and k.sha(data/'PHASE_LIMITS.json') == plan['phase_limits_sha256'], 'Same frozen main/pools')
k.require(k.read(data/'preparation/CONSTRUCTOR_BATCH_RESULT.json')['records'] == 36 and
          k.read(data/'PANELS.json')['complete'] is True, 'Complete frozen constructor/panel inventory')
k.require(not any((data/name).exists() for name in ('physical', 'independent', 'ANALYSIS.json', 'figures')),
          'Run unattempted remaining phases once; preserve existing outputs')


def close_check(path, expected):
    final = k.read(path.with_name(path.name.replace('.PLAN.json', '.FINAL.json')))
    receipt_path = data/final['receipt_path']; receipt = k.read(receipt_path)
    k.require(final['plan_sha256'] == k.sha(path) and final['receipt_sha256'] == k.sha(receipt_path)
              and final['guard_supervisor_exit_code'] == receipt['exit_code'] == expected
              and receipt.get('termination') is None and receipt.get('guard_error') is None
              and not receipt.get('cleanup_errors'), 'Exact expected terminal receipt, never generic nonzero acceptance')


# Both original objective invocations are terminal. No numerical retry occurs.
raw_censors = []
for case in h['cases']:
    target = data/'objective'/case/'OBJECTIVE.toml'
    k.require(k.sha(target) == plan['original_objective_reports'][case], 'Original objective report bytes')
    value = tomllib.loads(target.read_text())
    k.require(len(value['logical_rows']) == value['processed_logical_rows'] == 72 and
              all(row['status'] == 'verified' for row in value['logical_rows']) and
              all(row['status'] == 'replayed' for row in value['checks']) and not value['failures'] and
              value['mismatched_objectives'] == value['floor_censored_objectives'] == 0 and
              value['processed_raw_witnesses'] == value['expected_raw_witnesses'] == len(value['raw_witnesses']),
              'Every selected score and persisted proposed score was actually replayed')
    for row in value['raw_witnesses']:
        k.require(row['proposed_comparison']['verified'] is True, 'Independent proposed score agreement required')
        if row['status'] != 'verified':
            raw_censors.append((case, row))
    expected_exit = 2 if case == 'HF_r1p00_631g_12m8e' else 0
    k.require(value['status'] == ('partial_or_censored' if expected_exit else 'complete') and
              value['complete'] is (expected_exit == 0), 'Preserve original censored versus complete statuses')
    close_check(data/'jobs'/('mg-objective-'+case.lower().replace('_', '-')+'.PLAN.json'), expected_exit)
k.require(len(raw_censors) == 1, 'Exactly one known raw native censor')
case, row = raw_censors[0]
k.require(case == 'HF_r1p00_631g_12m8e' and row['name'] == 'rep2.window.B64.raw1' and
          row['status'] == 'native_refusal_censored' and row['selected'] is False and
          'native_score' not in row and json.loads(row['native_refusal']) ==
          dict(type='SearchDeadline', message='whole-call window allowance exhausted'),
          'Authenticate exact original unpromoted native deadline refusal')
for path in (data/'jobs').glob('*.PLAN.json'):
    label = k.read(path)['label']
    close_check(path, 2 if label == 'mg-objective-hf-r1p00-631g-12m8e' else 0)

for phase in ('physical', 'independent'):
    cpu, wall = plan['per_case_dispatch'][phase]
    runner.validation(data, phase, cpu, wall)
    filename = 'PHYSICAL.toml' if phase == 'physical' else 'VERIFY.toml'
    for case in h['cases']:
        value = tomllib.loads((data/phase/case/filename).read_text())
        k.require(value['status'] == 'complete' and len(value['rows']) == value['completed_logical_rows'] == 72
                  and not value['failures'], 'Complete actual full logical physical/replay inventory')
        if phase == 'independent':
            k.require(value['reference_check_count'] == len(value['reference_checks']) == 2
                      and not value['censored_rows'], 'Both fresh references and no censored physical replay')
        close_check(data/'jobs'/('mg-'+phase+'-'+case.lower().replace('_', '-')+'.PLAN.json'), 0)
    print('MAIN_REMAINING_PHASE_COMPLETE', phase, flush=True)

cpu, wall = plan['metadata_dispatch']['analysis']
runner.dispatch(data, 'mg-main-analysis-a1', 'analysis',
                [sys.executable, str(k.HERE/'analyze.py'), str(data), str(data/'ANALYSIS.json')], cpu, wall, 512)
close_check(data/'jobs/mg-main-analysis-a1.PLAN.json', 2)
value = k.read(data/'ANALYSIS.json')
k.require(value['complete'] is False and value['status'] == 'incomplete' and
          len(value['retained_physical_rows']) == len(value['retained_independent_rows']) ==
          len(value['retained_objective_rows']) == 144 and len(value['named_pairs']) == 64 and
          all(row['status'] == 'verified' for row in value['retained_objective_rows']) and
          all(question['decision'] == 'incomplete' for question in value['primary'].values()),
          'Complete observed inventory retains frozen incomplete scientific and primary gates')
k.require(len(value['issues']) == 1 and value['issues'][0]['phase'] == 'scientific_receipts' and
          value['issues'][0]['message'] == 'Scientific post-teardown FINAL/PLAN/receipt chain',
          'Only the unchanged analyzer receipt refusal from original objective exit2 is expected')
cases = {row['case']: row for row in value['cases_metadata']}
k.require(set(cases) == set(h['cases']) and not any(row['issues'] for row in cases.values()) and
          cases['HF_r1p00_631g_12m8e']['complete'] is False and
          cases['HF_r1p00_631g_12m8e']['raw_claims_verified'] is False and
          cases['H2S_r1p40_a96_631g_12m8e']['complete'] is True and
          cases['H2S_r1p40_a96_631g_12m8e']['raw_claims_verified'] is True,
          'No unexpected scientific omission or mismatch may hide behind the known censor')
print('MAIN_ANALYSIS_PRESERVED_INCOMPLETE_KNOWN_NATIVE_CENSOR', flush=True)
cpu, wall = plan['metadata_dispatch']['figures']
runner.dispatch(data, 'mg-main-figures-a1', 'analysis',
                [sys.executable, str(k.HERE/'plot.py'), str(data/'ANALYSIS.json'), str(data/'figures')], cpu, wall, 512)
close_check(data/'jobs/mg-main-figures-a1.PLAN.json', 0)
print('MAIN_PLANNED_NUMERICAL_MATRIX_CLOSED_SCIENTIFIC_GATE_INCOMPLETE', flush=True)
