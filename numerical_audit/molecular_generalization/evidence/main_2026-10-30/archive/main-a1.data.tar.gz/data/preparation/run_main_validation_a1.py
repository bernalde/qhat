"""Continue the frozen main batch once through bounded scientific producers.

No order construction or scientific identity retry occurs here. Every numerical
command uses the already frozen runner and phase pool. Inspect actual terminal
receipts and reports; a successful dispatcher alone is insufficient.
"""
import json
from pathlib import Path
import subprocess
import sys
import tomllib

planpath = Path(sys.argv[1]).resolve()
plan = json.loads(planpath.read_text())
source, data = Path(plan['producer_root']), Path(plan['data_root'])
sys.path.insert(0, str(source/'numerical_audit/molecular_generalization'))
import common as k
import runner

k.require(k.sha(Path(__file__)) == plan['operator_sha256'], 'Exact main validation dispatcher')
k.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
          == plan['source_commit'], 'Frozen producer HEAD')
k.require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source, text=True),
          'Frozen producer checkout must remain clean')
h, config = k.header(data, producer=True)
k.require(h['mode'] == 'main' and config['main_execution_allowed'] is True,
          'Only the authenticated prospective main protocol')
k.require(k.sha(data/'INPUT_PROTOCOL_FROZEN.json') == plan['source_freeze_sha256'] and
          k.sha(data/'PHASE_LIMITS.json') == plan['phase_limits_sha256'], 'Frozen source and phase pools')
batch = k.read(data/'preparation/CONSTRUCTOR_BATCH_RESULT.json')
k.require(batch['complete_inventory'] is True and batch['records'] == 36 and
          batch['all_orders_frozen_before_any_new_physical_error'] is True,
          'All 36 constructor identities must close before new physical errors')
k.require(len(k.read(data/'PARENTS_FROZEN.json')['entries']) == 4 and
          len(k.read(data/'CONSTRUCTORS_FROZEN.json')['entries']) == 32, 'Exact constructor index matrix')
k.require(not (data/'PANELS.json').exists() and not (data/'ANALYSIS.json').exists() and
          not any((data/name).exists() for name in ('objective', 'physical', 'independent', 'figures')),
          'Fresh validation phases; resume the same live handle rather than rerunning')


def closed_phase(phase):
    paths = [p for p in (data/'jobs').glob('*.PLAN.json') if k.read(p)['phase'] == phase]
    k.require(paths, 'Retained owning phase PLAN')
    for path in paths:
        final = k.read(path.with_name(path.name.replace('.PLAN.json', '.FINAL.json')))
        receipt = k.read(data/final['receipt_path'])
        k.require(final['plan_sha256'] == k.sha(path) and
                  final['receipt_sha256'] == k.sha(data/final['receipt_path']) and
                  final['guard_supervisor_exit_code'] == 0 and receipt['exit_code'] == 0 and
                  receipt.get('termination') is None and receipt.get('guard_error') is None and
                  not receipt.get('cleanup_errors'), 'Successful terminal phase receipt required')


for phase in ('panels', 'objective', 'physical', 'independent', 'analysis'):
    if phase in ('objective', 'physical', 'independent'):
        cpu, wall = plan['per_case_dispatch'][phase]
        runner.validation(data, phase, cpu, wall)
        filename = {'objective': 'OBJECTIVE.toml', 'physical': 'PHYSICAL.toml',
                    'independent': 'VERIFY.toml'}[phase]
        for case in h['cases']:
            report = tomllib.loads((data/phase/case/filename).read_text())
            k.require(report.get('status') == 'complete', 'Complete scientific phase report required')
            rows_key = {'objective': 'logical_rows', 'physical': 'rows', 'independent': 'rows'}[phase]
            k.require(len(report[rows_key]) == 72, 'All 72 logical rows per case must remain represented')
            if phase == 'objective':
                k.require(report['complete'] is True and report['all_scored_objectives_verified'] is True,
                          'Every selected and persisted raw objective claim must verify')
            if phase == 'independent':
                k.require(report['reference_check_count'] == 2 and len(report['reference_checks']) == 2,
                          'Both independent reference times per case')
    else:
        command = ([sys.executable, str(k.HERE/'panels.py'), 'produce', str(data)]
                   if phase == 'panels' else
                   [sys.executable, str(k.HERE/'analyze.py'), str(data), str(data/'ANALYSIS.json')])
        cpu, wall = plan['metadata_dispatch'][phase]
        runner.dispatch(data, 'mg-main-'+phase+'-a1', phase, command, cpu, wall, 512)
        report = k.read(data/('PANELS.json' if phase == 'panels' else 'ANALYSIS.json'))
        k.require(report.get('complete') is True, 'Complete authenticated metadata analysis required')
        if phase == 'analysis':
            k.require(len(report['retained_physical_rows']) == len(report['retained_independent_rows']) ==
                      len(report['retained_objective_rows']) == 144 and len(report['named_pairs']) == 64,
                      'Complete frozen logical and paired-result grids')
    closed_phase(phase)
    print('MAIN_PHASE_COMPLETE', phase, flush=True)

cpu, wall = plan['metadata_dispatch']['figures']
runner.dispatch(data, 'mg-main-figures-a1', 'analysis',
                [sys.executable, str(k.HERE/'plot.py'), str(data/'ANALYSIS.json'), str(data/'figures')],
                cpu, wall, 512)
closed_phase('analysis')
print('MAIN_PRODUCER_COMPLETE_AWAIT_VISUAL_AND_ARCHIVED_NUMERICAL_REPLAY', flush=True)
