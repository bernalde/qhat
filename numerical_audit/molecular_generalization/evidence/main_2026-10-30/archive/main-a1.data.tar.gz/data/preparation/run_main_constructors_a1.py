"""Run the frozen complete main constructor matrix once, preserving every result."""
import json,sys
from pathlib import Path
planpath=Path(sys.argv[1]).resolve();plan=json.loads(planpath.read_text());source=Path(plan['producer_root'])
sys.path.insert(0,str(source/'numerical_audit/molecular_generalization'))
import common as k
import runner
k.require(k.sha(Path(__file__))==plan['operator_sha256'],'Exact constructor dispatcher')
data=Path(plan['data_root']);h,config=k.header(data,producer=True)
k.require(h['mode']=='main' and k.frozen(data)['source_commit']==plan['source_commit'],'Exact prospective main source')
k.require(k.sha(data/'INPUTS_FROZEN.json')==plan['inputs_frozen_sha256'] and k.read(data/'INPUTS_FROZEN.json')['status']=='complete','Authenticated complete inputs')
k.require(not(data/'PARENTS_FROZEN.json').exists() and not(data/'CONSTRUCTORS_FROZEN.json').exists(),'Fresh batch; resume live handles, never restart attempted scientific identities')
runner.constructors(data)
parents=k.read(data/'PARENTS_FROZEN.json');others=k.read(data/'CONSTRUCTORS_FROZEN.json')
k.require(len(parents['entries'])==4 and len(others['entries'])==32,'Complete36-record matrix')
rows=[k.read(data/entry['path'])for entry in parents['entries']+others['entries']]
k.require(len(list((data/'constructors').glob('*.json')))==36,'No missing or extra constructor identities')
k.write_new(data/'preparation/CONSTRUCTOR_BATCH_RESULT.json',dict(complete_inventory=True,records=36,eligible=sum(row['eligible']for row in rows),capacity_and_refusals_retained=True,all_orders_frozen_before_any_new_physical_error=True,physical_error_executed=False))
print('MAIN_ALL36_CONSTRUCTORS_FROZEN',flush=True)
