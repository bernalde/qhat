"""Metadata-only dispatch for the frozen old-LiH preflight phases."""
import json
from pathlib import Path
import sys

source=Path('/tmp/qhat-molecular-generalization-2026-10-30/worktree')
sys.path.insert(0,str(source/'numerical_audit/molecular_generalization'))
import common as k
import runner

data=Path('/home/bernalde/repos/Fermionic_Trotterization/dist/molecular_generalization_2026-10-30/runs/preflight-a4/data')
phase=sys.argv[1]
k.require(phase in ('panels','objective','physical','independent','analysis'),'Named old-preflight phase')
h,config=k.header(data,producer=True)
k.require(h['mode']=='preflight' and not config['main_execution_allowed'],'Only frozen old preflight')
limits=k.read(data/'PHASE_LIMITS.json')['phases'][phase]
cpu,wall=limits['CPU_seconds'],limits['wall_seconds']
if phase in ('physical','independent','objective'):
 runner.validation(data,phase,cpu,wall)
 case=h['cases'][0]
 filename={'physical':'PHYSICAL.toml','independent':'VERIFY.toml','objective':'OBJECTIVE.toml'}[phase]
 import tomllib
 report=tomllib.loads((data/phase/case/filename).read_text())
 complete=report.get('complete') is True or report.get('status')=='complete'
else:
 command=([sys.executable,str(k.HERE/'panels.py'),'produce',str(data),'--preflight'] if phase=='panels' else [sys.executable,str(k.HERE/'analyze.py'),str(data),str(data/'ANALYSIS.json'),'--preflight'])
 runner.dispatch(data,'mg-old-preflight-'+phase+'-a4',phase,command,cpu,wall,512)
 report=k.read(data/('PANELS.json' if phase=='panels' else 'ANALYSIS.json'))
 complete=report.get('complete') is True
plans=[p for p in (data/'jobs').glob('*.PLAN.json') if k.read(p)['phase']==phase]
k.require(plans,'Owning phase job retained')
for plan in plans:
 final=k.read(plan.with_name(plan.name.replace('.PLAN.json','.FINAL.json')))
 receipt=k.read(data/final['receipt_path'])
 k.require(final['guard_supervisor_exit_code']==0 and receipt['exit_code']==0 and receipt.get('termination') is None and receipt.get('guard_error') is None and not receipt.get('cleanup_errors'),'Successful terminal phase receipt required')
k.require(complete,'Complete scientific phase report required; retain partial evidence')
print('OLD_PREFLIGHT_PHASE_COMPLETE',phase,flush=True)
