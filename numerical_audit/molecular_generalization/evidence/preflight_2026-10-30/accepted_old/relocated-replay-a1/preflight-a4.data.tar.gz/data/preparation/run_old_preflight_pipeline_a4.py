"""Continue ONLY successful old-a4 credibility through existing bounded producers."""
import json,subprocess,sys
from pathlib import Path
r=Path('/home/bernalde/repos/Fermionic_Trotterization/dist/molecular_generalization_2026-10-30')
source=Path('/tmp/qhat-molecular-generalization-2026-10-30/worktree')
data=r/'runs/preflight-a4/data'
assert json.loads((data/'SA_CREDIBILITY.json').read_text())['complete'] is True
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()=='79eff7fe5d2aa7a159d718fa3bd32f77b54eda95'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True)
subprocess.run([sys.executable,str(r/'preflight/run_old_preflight_constructors_a2.py'),str(r/'runs/preflight-a4/CONSTRUCTOR_DISPATCH.PLAN.json'),'remaining'],cwd=source,check=True)
for phase in ('panels','objective','physical','independent','analysis'):
    subprocess.run([sys.executable,str(r/'preflight/run_old_preflight_phase_a4.py'),phase],cwd=source,check=True)
sys.path.insert(0,str(source/'numerical_audit/molecular_generalization'))
import common as k
import runner
command=[sys.executable,str(k.HERE/'plot.py'),str(data/'ANALYSIS.json'),str(data/'figures'),'--preflight']
plan,receipt=runner.dispatch(data,'mg-old-preflight-figures-a4','analysis',command,10,60,512)
d=k.read(receipt)
k.require(d['exit_code']==0 and d.get('termination')is None and d.get('guard_error')is None,'Successful actual figure render required')
print('OLD_PREFLIGHT_PRODUCER_COMPLETE_AWAIT_VISUAL_AND_RELOCATED_REPLAY',flush=True)
