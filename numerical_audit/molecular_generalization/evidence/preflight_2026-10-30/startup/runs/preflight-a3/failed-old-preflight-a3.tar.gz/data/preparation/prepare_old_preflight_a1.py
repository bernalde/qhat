"""Metadata/input-copy operator for one declared OLD LiH preflight."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

plan_path=Path(sys.argv[1]).resolve()
plan=json.loads(plan_path.read_text())
source=Path(plan['producer_root'])
sys.path.insert(0,str(source/'numerical_audit/molecular_generalization'))
import common as k
import generate_inputs as generate
import runner

k.require(plan['mode']=='preflight' and plan['case']=='LiH_r1p487_631g_14m4e','Old-only named preflight')
k.require(k.committed_sources()==plan['source_commit'],'Committed declared producer')
k.require(k.configuration()['main_execution_allowed'] is False,'Main must remain disabled')
k.require(hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==plan['operator_sha256'],'Exact operator bytes')
limits=Path(plan['phase_limits'])
k.require(k.sha(limits)==plan['phase_limits_sha256'],'Declared finite phase pools')
data=Path(plan['data_root'])
k.freeze(data,mode='preflight')
generate.old_input(data)
k.require(generate.finalize(data),'Complete authenticated old input')
runner.initialize(data,k.read(limits))
folder=data/'preparation'
folder.mkdir()
for path in (plan_path,Path(__file__).resolve(),limits):
 shutil.copyfile(path,folder/path.name)
k.write_new(folder/'PREPARED.json',dict(complete=True,case=plan['case'],mode='preflight',source_commit=plan['source_commit'],source_freeze_sha256=k.sha(data/'INPUT_PROTOCOL_FROZEN.json'),input_sha256=k.sha(data/'INPUTS_FROZEN.json'),old_input_reused=True,new_chemistry_computed=False,new_family_errors_observed=False))
print('OLD_PREFLIGHT_PREPARED',str(data),flush=True)
