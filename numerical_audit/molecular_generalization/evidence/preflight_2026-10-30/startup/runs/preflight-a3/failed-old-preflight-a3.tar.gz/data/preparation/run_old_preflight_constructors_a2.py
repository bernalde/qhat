"""Old-only dispatch: test annealing credibility before spending on the other arms.

Each scientific worker, allowance, receipt and finalizer is the unchanged runner
API. This operator only changes OLD preflight dispatch order and checks a gate.
"""
import hashlib,json,sys
from pathlib import Path
plan_path=Path(sys.argv[1]);stage=sys.argv[2]
plan=json.loads(plan_path.read_text());source=Path(plan['producer_root'])
sys.path.insert(0,str(source/'numerical_audit/molecular_generalization'))
import common as k
import construct
import runner
k.require(stage in ('annealing-first','remaining'),'Declared old preflight stage')
k.require(hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==plan['operator_sha256'],'Exact dispatch operator')
data=Path(plan['data_root']);h,config=k.header(data,producer=True)
k.require(h['mode']=='preflight' and config['main_execution_allowed'] is False,'Old-only pipeline')
k.require(k.frozen(data)['source_commit']==plan['source_commit'],'Exact committed producer freeze')
julia=k.frozen(data)['runtime']['julia']['executable']

def one(case,rep,arm,budget):
 target=k.constructor_path(data,case,rep,arm,budget)
 k.require(not target.exists(),'Preserve attempted constructor identity')
 parent,_=construct.parent(data,case,rep) if arm in k.ARMS else (None,None)
 cpu,wall=construct.allowances(config,arm,budget,parent)
 label=f'mg-{case.lower().replace("_","-")}-r{rep}-{arm}-b{budget}'
 raw=data/'workers'/(label+'.json');raw.parent.mkdir(exist_ok=True)
 command=[sys.executable,str(k.HERE/'construct.py'),'--data',str(data),'--worker','--case',case,'--repetition',str(rep),'--arm',arm,'--budget',str(budget),'--cpu-cap',repr(cpu),'--wall-cap',str(wall),'--raw',str(raw),'--julia-executable',julia]
 job,receipt=runner.dispatch(data,label,'constructors',command,cpu,wall,512,identity=dict(case=case,repetition=rep,arm=arm,cpu_budget=budget),expected_raw=str(raw.relative_to(data)))
 value=construct.finalize(data,case,rep,arm,budget,raw,job,receipt)
 print('FINALIZED',case,rep,arm,budget,'eligible',value['eligible'],flush=True)
 return value

if stage=='annealing-first':
 for case in h['cases']:
  for rep in range(1,h['repetitions']+1):one(case,rep,'parent',0)
 construct.freeze(data,True)
 rows=[]
 for case in h['cases']:
  for rep in range(1,h['repetitions']+1):
   for budget in k.BUDGETS:
    value=one(case,rep,'annealing',budget)
    result=value.get('result')or{};stats=result.get('stats')or{};witness=(result.get('raw_julia_candidate')or{}).get('witness',{})
    proposals=witness.get('chain_proposals',[])
    credible=value['eligible'] is True and witness.get('start_scores_completed')==4 and len(proposals)==4 and all(type(n)is int and n>0 for n in proposals) and stats.get('native_verifications',0)>=1 and stats.get('child_reaped')is True
    rows.append(dict(case=case,repetition=rep,budget=budget,credible=credible,constructor=str(k.constructor_path(data,case,rep,'annealing',budget).relative_to(data)),start_scores_completed=witness.get('start_scores_completed'),chain_proposals=proposals,native_verifications=stats.get('native_verifications'),eligible=value['eligible']))
 complete=all(row['credible'] for row in rows)
 k.write_new(data/'SA_CREDIBILITY.json',dict(schema='molecular-old-annealing-credibility-v1',complete=complete,rows=rows,dispatch_plan_sha256=k.sha(plan_path),physical_errors_read=False))
 k.require(complete,'Old annealing credibility gate failed;retain this partial preflight and all costs')
else:
 k.require(k.read(data/'SA_CREDIBILITY.json')['complete']is True,'Credible old annealing required first')
 for case in h['cases']:
  for rep,arm,budget in k.identities(h['repetitions']):
   if arm not in ('parent','annealing'):one(case,rep,arm,budget)
 construct.freeze(data,False)
 print('ALL_OLD_CONSTRUCTORS_FROZEN',flush=True)
