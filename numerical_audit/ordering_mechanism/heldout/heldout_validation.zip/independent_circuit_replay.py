#!/usr/bin/env python3
"""Independent in-place Pauli-pair product implementation; imports no QHAT."""
import os
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS'):os.environ[name]='2'
os.environ['NUMBA_CACHE_DIR']='/tmp/ordering-heldout-validation/independent-numba-cache'
import argparse,hashlib,json,time
from pathlib import Path
import numpy as np
from numba import njit

def require(ok,msg):
    if not ok:raise RuntimeError(msg)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

@njit(cache=True)
def pair_product(initial,flips,signs,cosines,sines,parity,steps):
    """Apply real Hermitian Pauli involutions through disjoint 2x2 blocks."""
    state=initial.copy()
    for _ in range(steps):
        for k in range(len(flips)):
            flip=flips[k];signmask=signs[k];cosine=cosines[k];sine=sines[k]
            if flip==0:
                for i in range(len(state)):
                    sign=1-2*parity[i&signmask]
                    state[i]*=complex(cosine,-sine*sign)
            else:
                for i in range(len(state)):
                    j=i^flip
                    if i<j:
                        sign=1-2*parity[i&signmask]
                        left=state[i];right=state[j]
                        state[i]=cosine*left-1j*(sine*sign)*right
                        state[j]=cosine*right-1j*(sine*sign)*left
    return state

def descriptors(design,method):
    n=design['n_qubits'];basis=np.array(design['affine_basis_indices'],dtype=np.int64);dim=len(basis)
    require(dim&(dim-1)==0,'Affine size not power of two')
    positions=np.full(1<<n,-1,dtype=np.int64);positions[basis]=np.arange(dim)
    translation=int(basis[0]);generators=[int(basis[1<<j])^translation for j in range(dim.bit_length()-1)]
    flips=[];signs=[];cosines=[];sines=[];checked=set();den=int(design['denominator'])
    for key,num in design['flat_schedules'][method]:
        x=z=y=0
        for q,p in key:
            bit=1<<(n-1-int(q))
            if p in ('X','Y'):x|=bit
            if p in ('Y','Z'):z|=bit
            if p=='Y':y+=1
        require(y%2==0,'This standalone real-pair kernel requires even Y count')
        flip=int(positions[translation^x]);require(flip>=0,'Pauli leaves selected closure')
        if x not in checked:
            require(np.array_equal(positions[basis^x],np.arange(dim)^flip),'Affine XOR descriptor mismatch')
            checked.add(x)
        sign=sum(((g&z).bit_count()%2)<<j for j,g in enumerate(generators))
        require((flip&sign).bit_count()%2==0,'Real Pauli must have equal partner signs')
        basephase=(-1)**((translation&z).bit_count()+y//2)
        angle=int(num)/den/100
        flips.append(flip);signs.append(sign);cosines.append(np.cos(angle));sines.append(basephase*np.sin(angle))
    return np.array(flips,np.int64),np.array(signs,np.int64),np.array(cosines),np.array(sines)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=False)
    plan=[('li2_coeff1p00',method) for method in ('class_refined_response','owned_signed','jw_signed','jw_magnitude','class_lex')]
    plan += [('f2_coeff1p00','class_refined_response'),('nh3_coeff1p00','class_refined_response')]
    rows=[];saved={}
    for case,method in plan:
        design=json.loads((args.results/f'{case}.design.json').read_text());completed=json.loads((args.results/f'{case}.completed.json').read_text())
        require(sha(args.results/f'{case}.states.npz')==completed['states_sha256'],'Saved source state changed')
        with np.load(args.results/f'{case}.states.npz',allow_pickle=False) as reference:
            initial=reference['initial'];expected=reference[method];exact=reference['exact']
            masks=descriptors(design,method);parity=np.array([i.bit_count()%2 for i in range(len(initial))],dtype=np.int8)
            started=time.monotonic();actual=pair_product(initial,*masks,parity,100);seconds=time.monotonic()-started
            distance=float(np.linalg.norm(actual-expected));require(distance<1e-10,'Independent full product disagrees')
            u=exact/np.linalg.norm(exact);v=actual/np.linalg.norm(actual);o=np.vdot(u,v)
            difference=u-v*np.conjugate(o)/abs(o);E=.5*float(np.vdot(difference,difference).real)
            original=next(r for r in completed['rows'] if r['ordering']==method)
            require(abs(E-original['one_minus_overlap'])<1e-15,'Independent evolved error differs')
            row={'case':case,'method':method,'steps':100,'time':1.,'state_distance':distance,'one_minus_overlap':E,
                 'metric_difference':abs(E-original['one_minus_overlap']),'seconds':seconds,
                 'norm':float(np.linalg.norm(actual)),'dimension':len(actual),'source_design_sha256':sha(args.results/f'{case}.design.json')}
            rows.append(row);saved[f'{case}__{method}']=actual;print(json.dumps(row),flush=True)
    np.savez_compressed(args.output/'states.npz',**saved)
    with (args.output/'results.json').open('x') as f:json.dump({'rows':rows,'states_sha256':sha(args.output/'states.npz'),'script_sha256':sha(__file__),
        'implementation':'Independent in-place disjoint 2x2 Pauli-pair updates; masks derived from physical basis and written letters; no QHAT imports.'},f,indent=2);f.write('\n')

if __name__=='__main__':main()
