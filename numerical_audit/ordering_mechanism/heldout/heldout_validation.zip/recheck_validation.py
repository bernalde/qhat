#!/usr/bin/env python3
"""Independent NumPy state/hash/leakage replay and local-defect objective check."""
import os
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='2'
import argparse,hashlib,json
from pathlib import Path
import numpy as np

def require(ok,message):
    if not ok:raise RuntimeError(message)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def objsha(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def arrsha(arr):return objsha({'shape':arr.shape,'dtype':arr.dtype.str,'raw_sha256':hashlib.sha256(arr.tobytes()).hexdigest()})
def decode(records):return {tuple((int(q),letter) for q,letter in key):int(v) for key,v in records}

def local_defect_objective(design,initial):
    n=design['n_qubits'];den=int(design['denominator']);basis=np.array(design['affine_basis_indices'],dtype=np.int64)
    positions=np.full(1<<n,-1,dtype=np.int64);positions[basis]=np.arange(len(basis))
    parity=np.array([x.bit_count()%2 for x in range(1<<n)],dtype=np.int8)
    def descriptor(key):
        flip=sign=y=0
        for q,letter in key:
            bit=1<<(n-1-q)
            if letter in ('X','Y'):flip|=bit
            if letter in ('Y','Z'):sign|=bit
            if letter=='Y':y+=1
        return flip,sign,y
    def action(key,v):
        flip,sign,y=descriptor(key);physical_source=basis^flip;source=positions[physical_source]
        require(np.all(source>=0),'Not closed under an actual Pauli')
        return ((1j**y)*(1-2*parity[physical_source&sign]))*v[source]
    coefficients=decode(design['coefficients'])
    def H(v):
        result=np.zeros_like(v)
        for key,num in coefficients.items():result+=(num/den)*action(key,v)
        return result
    first=np.zeros_like(initial);second=np.zeros_like(initial)
    for key,num in design['flat_schedules']['class_refined_response']:
        key=tuple((int(q),letter) for q,letter in key);c=int(num)/den
        second-=1j*c*action(key,first)+.5*c*c*initial
        first-=1j*c*action(key,initial)
    defect=second+.5*H(H(initial))
    diagonal=np.zeros(len(basis))
    for key,num in coefficients.items():
        flip,sign,y=descriptor(key)
        if flip==0:diagonal+=(num/den)*(1-2*parity[basis&sign])
    rho=np.sinc((diagonal-diagonal[0])/(2*np.pi))**2
    independent=float(np.dot(rho,abs(defect)**2));expected=design['candidate_objective']
    require(abs(independent-expected)<max(1e-16,1e-6*expected),'Independent local-defect objective mismatch')
    return {'independent_diagonal_response_objective':independent,'frozen_candidate_objective':expected,
            'absolute_difference':abs(independent-expected),'relative_difference':abs(independent-expected)/expected if expected else None,
            'method':'Floating second-order coefficient of the actual chronological Pauli product minus exact exponential, followed by diagonal-reference sinc weighting. No candidate pair-amplitude functions used.',
            'local_defect_norm':float(np.linalg.norm(defect)),'local_defect_HF_projection_abs':float(abs(np.vdot(initial,defect)))}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();root=args.results
    manifest=json.loads((root/'manifest.json').read_text());frozen=json.loads((root/'ALL_CANDIDATES_FROZEN.json').read_text())
    for name,digest in manifest['source_sha256'].items():require(sha(root/name)==digest,'Source hash mismatch')
    metrics=[];objectives=[];count=0;maxdiff=maxleak=0.
    for file in sorted(root.glob('*.completed.json')):
        result=json.loads(file.read_text());case=file.name.removesuffix('.completed.json');d=json.loads((root/f'{case}.design.json').read_text())
        require(sha(root/f'{case}.design.json')==frozen['design_hashes'][case],'Candidate changed after freeze')
        for suffix,key in [('design.json','design_sha256'),('checks.json','checks_sha256'),('states.npz','states_sha256'),('initial.npz','initial_file_sha256')]:
            require(sha(root/f'{case}.{suffix}')==result[key],f'File hash mismatch {case}.{suffix}')
        n=d['n_qubits'];basis=np.array(d['affine_basis_indices']);alpha=sum(1<<(n-1-q) for q in range(0,n,2));beta=sum(1<<(n-1-q) for q in range(1,n,2));electrons=d['electrons']
        nm=np.array([int(x).bit_count()==electrons for x in basis]);sm=np.array([(int(x)&alpha).bit_count()==electrons//2 and (int(x)&beta).bit_count()==electrons//2 for x in basis])
        with np.load(root/f'{case}.states.npz',allow_pickle=False) as z,np.load(root/f'{case}.initial.npz',allow_pickle=False) as frozen_initial:
            for key,digest in result['state_arrays_sha256'].items():require(arrsha(z[key])==digest,'State hash mismatch')
            require(np.array_equal(z['initial'],frozen_initial['initial']),'Initial changed')
            for row in result['rows']:
                u=z['exact']/np.linalg.norm(z['exact']);v=z[row['ordering']]/np.linalg.norm(z[row['ordering']]);o=np.vdot(u,v)
                difference=u-v*np.conjugate(o)/abs(o);E=.5*float(np.vdot(difference,difference).real)
                require(abs(E-row['one_minus_overlap'])<1e-16,'Independent stable metric mismatch')
                leakage=float(np.vdot(v[~nm],v[~nm]).real)
                spinleak=float(np.vdot(v[~sm],v[~sm]).real)
                ld=max(abs(leakage-row['particle_number_leakage']),abs(spinleak-row['spin_sector_leakage']))
                require(ld<1e-18,'Independent leakage mismatch')
                maxdiff=max(maxdiff,abs(E-row['one_minus_overlap']));maxleak=max(maxleak,ld);count+=1
                metrics.append({'case':case,'ordering':row['ordering'],'E':E})
            objective=local_defect_objective(d,z['initial']);objectives.append({'case':case,**objective})
            print(case,objective,flush=True)
    require(count==30,'Incomplete prospective validation')
    output={'completed_rows':count,'max_independent_metric_difference':maxdiff,'max_independent_leakage_difference':maxleak,'objective_checks':objectives,'metrics':metrics,
            'scope':'Saved-state and hash replay, plus an independent local-error/diagonal-response computation. This is not a second independent full Trotter propagation.'}
    with args.output.open('x') as f:json.dump(output,f,indent=2);f.write('\n')
    print('PASS',count,maxdiff,maxleak)

if __name__=='__main__':main()
