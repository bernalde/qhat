# Prospective frozen-candidate validation

Freeze the split-diagonal / ten best-insertion algorithm from phase2 before
computing new errors on Li2, F2, or NH3. Its exact source SHA-256 is
58263730c8c35b2dedbad845574c3f4f4286af5c0328940d001af85ddd18ecd7.
Import its unchanged pair_setup, amplitudes, cost, and optimize functions.
No algorithm or parameter adjustment using this panel is allowed.

Six cases: frozen li2, f2, nh3 tensors, each with coefficient multipliers 1
and 5/4. These are FIXED geometries. Apply multipliers to the already-screened
exact dyadic Hermitian parent target (whole-parent cutoff 1e-12, no individual
Pauli cutoff), so supports do not change. Development names s1.00/s1.25
were coordinate/geometry scales; these new coefficient controls are different
and are labelled coeff1p00/coeff1p25. Three molecules, not six independent ones.
The fixtures existed earlier but this candidate was not designed/evaluated on
them. Call this prospective candidate validation, not blinded data collection.

Five methods per case: frozen candidate, original signed first-owned blocks,
JW signed, JW magnitude, and original complete-class lexicographic order.
All use the same identity-free Hamiltonian, HF state, T=1, r=100, and each
retained Pauli word exactly once per step. Freeze all six candidate schedules
and designs before computing any new approximate error.

Candidate partition: every zero-mask diagonal Pauli separately; each nonzero
flip-mask class kept intact. Start from fixed mask/word order and descending
unit coefficient-l1 with stable mask/index ties. Run unchanged optimizer for
ten best-improving insertions per start and choose using its original objective
and tie rules. Record total ordering construction time and accepted moves.
No exact dynamics or observed error enters selection.

Sparse references on the common affine closure of HF under every parent word
(including canceled words). Retain all number/spin leakage. Independently build
the complete same-closure Hamiltonian through occupation-basis CAR actions;
compare matrices. Validate sparse exponential by split time and independent
CAR-matrix exponential. Check actual block internal commutation, number
conservation, exact integer reconstruction, equal emitted-word count, and
independent sampled full-space Pauli rotations. No dense response diagnostic
or full eigendecomposition above 12 qubits (we omit that diagnostic altogether).

Thirty new evolutions. Report all cases and failures, stable normalized overlap
error E=1-|<exact,approx>|, infidelity, number/spin leakage, norms, target
corrections, exact coefficient denominators, source/input/state hashes, and
classical ordering runtime. Absolute tie tolerance and ratio floor 1e-12.
Run one memory-capped job, <=2 threads, <=6 GiB resident memory.
