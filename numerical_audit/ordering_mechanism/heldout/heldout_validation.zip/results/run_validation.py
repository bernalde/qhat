#!/usr/bin/env python3
"""Prospective evaluation of an unchanged, source-pinned ordering candidate."""
import os
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMBA_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[name]='2'
os.environ['NUMBA_CACHE_DIR']='/tmp/ordering-heldout-validation/numba-cache'
os.environ['MPLCONFIGDIR']='/tmp/ordering-heldout-validation/mpl-cache'
import argparse,copy,hashlib,json,resource,shutil,subprocess,time
from pathlib import Path
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import expm_multiply
import frozen_candidate as cand
import exact_blocks as eb
from qhat.analysis import benchmark_b2_signed_coefficient_baseline as baseline
from qhat.analysis import benchmark_b2_active_spaces_matrix_free as ev
from qhat.analysis.fermionic_coefficients import fermion_from_interaction
from qhat.numerical_audit import reference_tools as ref
from qhat.numerical_audit.run_frozen_audit import evolve,physical_metrics

ROOT=Path('/home/bernalde/repos/qhat');HERE=Path(__file__).resolve().parent
EXPECTED='58263730c8c35b2dedbad845574c3f4f4286af5c0328940d001af85ddd18ecd7'
METHODS=('class_refined_response','owned_signed','jw_signed','jw_magnitude','class_lex')

def require(ok,message):
    if not ok:raise RuntimeError(message)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def objsha(obj):return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def arrsha(arr):return objsha({'shape':arr.shape,'dtype':arr.dtype.str,'raw_sha256':hashlib.sha256(arr.tobytes()).hexdigest()})
def write(p,x):
    with Path(p).open('x') as f:json.dump(x,f,indent=2,allow_nan=False);f.write('\n')
def records(b):return [[k,str(v)] for k,v in sorted(b.items())]
def event(**x):print(json.dumps(x),flush=True)

def occupation_matrix(parents,den,basis,n):
    """Independent complete occupation-basis CAR action, without Pauli/JW code."""
    indices=np.array(basis,dtype=np.int64);positions={int(v):i for i,v in enumerate(indices)}
    parity=np.array([i.bit_count()%2 for i in range(1<<n)],dtype=np.int8)
    groups={}
    for parent in parents:
        key=parent['components'][0];partner,phase=eb.adjoint(key)
        components=[(key,parent['weight'])]+([] if partner==key else [(partner,phase*parent['weight'])])
        for monomial,c in components:
            current=indices.copy();amp=np.full(len(indices),c/den)
            for q,creation in reversed(monomial):
                bit=1<<(n-1-q);occupied=(current&bit)!=0
                amp*=np.where(occupied==bool(creation),0.,1.)
                amp*=1-2*parity[current>>(n-q)]
                current^=bit
            keep=amp!=0
            if not np.any(keep):continue
            flip=int(current[0]^indices[0]);require(np.all((current^indices)==flip),'Nonuniform CAR flip')
            if flip not in groups:groups[flip]=amp
            else:groups[flip]+=amp
    rows=[];cols=[];values=[]
    for flip,amp in groups.items():
        keep=np.flatnonzero(amp!=0)
        destinations=indices[keep]^flip
        require(all(int(x) in positions for x in destinations),'CAR closure not invariant')
        rows.append(np.array([positions[int(x)] for x in destinations]));cols.append(keep);values.append(amp[keep])
    H=sparse.coo_matrix((np.concatenate(values),(np.concatenate(rows),np.concatenate(cols))),shape=(len(indices),len(indices))).tocsr()
    return H-(sum(p['scalar'] for p in parents)/den)*sparse.eye(len(indices),format='csr')

def prepare(family,fixture,mult_num,mult_den,out):
    started=time.monotonic();case=f'{family}_coeff'+('1p00' if mult_num==1 else '1p25')
    tensor=ROOT/'numerical_audit/fixtures'/family/fixture['tensor']
    require(sha(tensor)==fixture['files'][fixture['tensor']],'Input tensor changed')
    interaction,n=baseline.load_interaction_operator(tensor);raw=fermion_from_interaction(interaction)
    parents,total,den,policy=eb.exact_parents(raw,1e-12)
    # Scale AFTER fixed support selection, as the frozen protocol requires.
    for p in parents:
        p['weight']*=mult_num;p['scalar']*=mult_num
        p['coefficients']={k:v*mult_num for k,v in p['coefficients'].items()}
    total={k:v*mult_num for k,v in total.items()};den*=mult_den
    pb,ob,cb,masks=eb.decompose(parents,total)
    for kind,blocks in (('parent',pb),('owned',ob),('class',cb)):
        reconstructed={}
        for b in blocks:
            eb.add_into(reconstructed,b)
            require(eb.internally_commuting(b) and not eb.number_commutator(b),f'Invalid {kind} block')
        require(reconstructed==total,'Integer reconstruction failed')
    bs=[];xs=[]
    for b,x in zip(cb,masks):
        for new in ([{word:value} for word,value in sorted(b.items())] if x==0 else [b]):bs.append(new);xs.append(x)
    require(sum(map(len,bs))==len(total),'Candidate duplicates words')
    event(event='starting_frozen_candidate',case=case,n=n,parents=len(parents),paulis=len(total),candidate_units=len(bs))
    ordering_started=time.monotonic();pairs,rho=cand.pair_setup(bs,xs,(1<<fixture['electrons'])-1,den)
    lex=list(range(len(bs)));mag=sorted(lex,key=lambda i:(-sum(abs(v) for v in bs[i].values()),xs[i]))
    starts=[cand.optimize(o,pairs,rho,den) for o in (lex,mag)];winner=starts[0]
    for c in starts[1:]:
        tolerance=max(1e-30,1e-12*min(winner[1],c[1]))
        if c[1]<winner[1]-tolerance or (abs(c[1]-winner[1])<=tolerance and tuple(c[0])<tuple(winner[0])):winner=c
    order,J,history=winner;ordering_seconds=time.monotonic()-ordering_started
    require(cand.cost(cand.amplitudes(list(reversed(order)),pairs),rho,den)==J,'Reversal check failed')
    coeff={k:v/den for k,v in total.items()}
    flat={'class_refined_response':[(k,v) for i in order for k,v in bs[i].items()],
          'owned_signed':[(k,v) for b in ob for k,v in b.items()],
          'class_lex':[(k,v) for b in cb for k,v in b.items()]}
    for name,keys in [('jw_signed',sorted(coeff,key=lambda k:(coeff[k],baseline.dense_pauli_string(k,n)))),
                      ('jw_magnitude',sorted(coeff,key=lambda k:(-abs(coeff[k]),baseline.dense_pauli_string(k,n))))]:flat[name]=[(k,total[k]) for k in keys]
    for schedule in flat.values():require(len(schedule)==len(total) and dict(schedule)==total,'Changed common target/cost')
    keys=sorted(set(total).union(*(set(b) for b in pb)))
    hf=((1<<fixture['electrons'])-1)<<(n-fixture['electrons'])
    basis,reduced,flipbasis=ref.affine_space(ev.compile_ordered_terms(keys,{k:1. for k in keys},n,0.),hf)
    unit=dict(zip(keys,reduced))
    def compile_word(k,v):return (v/den*unit[k][0],unit[k][1],unit[k][2],unit[k][3])
    compiled={name:[compile_word(k,v) for k,v in schedule] for name,schedule in flat.items()}
    design={'case':case,'family':family,'coefficient_multiplier':[mult_num,mult_den],
       'multiplier_interpretation':'Uniform scaling of fixed screened target, not geometry scaling',
       'n_qubits':n,'electrons':fixture['electrons'],'tensor_sha256':sha(tensor),'denominator':str(den),
       'base_target_coefficient_policy':policy,'coefficients':records(total),
       'blocks':{'parent':[records(b) for b in pb],'owned':[records(b) for b in ob],'class':[records(b) for b in cb],'candidate':[records(b) for b in bs]},
       'parent_metadata':[{'components':p['components'],'weight':str(p['weight']),'scalar':str(p['scalar'])} for p in parents],
       'class_flip_masks':masks,'candidate_flip_masks':xs,'candidate_order':order,
       'candidate_source_sha256':EXPECTED,'candidate_objective':J,'candidate_lex_objective':cand.cost(cand.amplitudes(lex,pairs),rho,den),
       'candidate_accepted_insertions':history,'candidate_start_results':[{'order':c[0],'J':c[1],'accepted_insertions':len(c[2])} for c in starts],
       'candidate_ordering_seconds':ordering_seconds,'preparation_seconds':time.monotonic()-started,
       'flat_schedules':{name:[[k,str(v)] for k,v in schedule] for name,schedule in flat.items()},
       'schedule_sha256':{name:objsha([[k,str(v)] for k,v in schedule]) for name,schedule in flat.items()},
       'affine_basis_indices':list(map(int,basis)),'affine_flip_basis':flipbasis,'closed_dimension':len(basis),
       'full_dimension':1<<n,'steps':100,'time':1.,'paulis_per_step':len(total),'state':'HF, q0 most significant, all closure leakage retained'}
    write(out/f'{case}.design.json',design)
    initial=np.zeros(len(basis),complex);initial[0]=1
    np.savez_compressed(out/f'{case}.initial.npz',initial=initial,affine_basis_indices=basis)
    event(event='candidate_frozen',case=case,n=n,parents=len(parents),paulis=len(total),candidate_units=len(bs),closure=len(basis),ordering_seconds=ordering_seconds,J=J)
    return case,design,parents,total,den,basis,unit,compiled,initial

def run_case(prepared,out):
    case,d,parents,total,den,basis,unit,compiled,initial=prepared;t=time.monotonic();n=d['n_qubits']
    terms=[(v/den*unit[k][0],unit[k][1],unit[k][2],unit[k][3]) for k,v in total.items()]
    H,_=ref.assemble_hamiltonian(terms,len(basis));independent=occupation_matrix(parents,den,basis,n)
    discrepancy=float(sparse.linalg.norm(H-independent));require(discrepancy<1e-9,'CAR/JW full matrix discrepancy')
    nm=np.array([int(x).bit_count()==d['electrons'] for x in basis])
    alpha=sum(1<<(n-1-q) for q in range(0,n,2));beta=sum(1<<(n-1-q) for q in range(1,n,2))
    sm=np.array([(int(x)&alpha).bit_count()==d['electrons']//2 and (int(x)&beta).bit_count()==d['electrons']//2 for x in basis])
    exact=expm_multiply(-1j*H,initial,traceA=-1j*H.diagonal().sum())
    alternate=expm_multiply(-1j*independent,initial,traceA=-1j*independent.diagonal().sum())
    half=expm_multiply(-.5j*H,initial,traceA=-.5j*H.diagonal().sum())
    split=expm_multiply(-.5j*H,half,traceA=-.5j*H.diagonal().sum())
    checks={'CAR_JW_matrix_frobenius':discrepancy,'independent_CAR_reference_distance':float(np.linalg.norm(exact-alternate)),
            'split_time_reference_distance':float(np.linalg.norm(exact-split)),
            'hermiticity_frobenius':float(sparse.linalg.norm(H-H.getH())),
            'off_spin_sector_frobenius':float(sparse.linalg.norm(H[~sm][:,sm])),'H_nnz':H.nnz}
    require(max(checks['independent_CAR_reference_distance'],checks['split_time_reference_distance'])<1e-10,'Reference check failed')
    # Sample actual physical Pauli rotations; retain full-space leakage in the check.
    selected=np.unique(np.linspace(0,len(total)-1,min(12,len(total)),dtype=int));keys=list(total)
    little=[compiled['jw_signed'][i] for i in range(min(12,len(compiled['jw_signed'])))]
    chosen=[tuple((int(q),p) for q,p in key) for key,_ in d['flat_schedules']['jw_signed'][:12]]
    raw=ev.compile_ordered_terms(chosen,{k:total[k]/den for k in chosen},n,0.)
    full_initial=np.zeros(1<<n,complex);full_initial[int(basis[0])]=1
    full,_=ev.evolve_trotter_state(full_initial,raw,1,1,.037,2**30);small=evolve(initial,little,.037,1)
    embedded=np.zeros_like(full);embedded[basis]=small
    checks['sample_full_vs_affine_distance']=float(np.linalg.norm(full-embedded));require(checks['sample_full_vs_affine_distance']<1e-11,'Affine signs mismatch')
    write(out/f'{case}.checks.json',checks)
    saved={'initial':initial,'exact':exact,'exact_independent_CAR':alternate,'affine_basis_indices':basis};rows=[]
    for name in METHODS:
        start=time.monotonic();actual=evolve(initial,compiled[name],1.,100)
        row={'case':case,'family':d['family'],'ordering':name,'T':1.,'steps':100,'role':'prospective_candidate_validation',
             'coefficient_multiplier':d['coefficient_multiplier'],'n_qubits':n,'electrons':d['electrons'],
             'pauli_rotations':len(compiled[name])*100,'seconds':time.monotonic()-start,
             'candidate_ordering_seconds':d['candidate_ordering_seconds'] if name=='class_refined_response' else None,
             'state_sha256':arrsha(actual),**physical_metrics(exact,actual,nm,sm)}
        require(abs(np.linalg.norm(actual)-1)<1e-8,'Norm drift')
        rows.append(row);saved[name]=actual;write(out/f'{case}.{name}.json',row)
        event(event='evolved',case=case,ordering=name,E=row['one_minus_overlap'],seconds=row['seconds'])
    np.savez_compressed(out/f'{case}.states.npz',**saved)
    write(out/f'{case}.completed.json',{'rows':rows,'elapsed_seconds':time.monotonic()-t,'design_sha256':sha(out/f'{case}.design.json'),
       'checks_sha256':sha(out/f'{case}.checks.json'),'states_sha256':sha(out/f'{case}.states.npz'),
       'initial_file_sha256':sha(out/f'{case}.initial.npz'),'state_arrays_sha256':{k:arrsha(v) for k,v in saved.items()},
       'peak_rss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
    return rows

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();out=args.output
    require(sha(HERE/'frozen_candidate.py')==EXPECTED,'Frozen candidate changed')
    require(Path(ev.__file__).resolve().is_relative_to(ROOT),'Wrong QHAT import')
    require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='0be7d4857537668eec957dabaa8438ea5c0d33f2','Wrong QHAT revision')
    out.mkdir(parents=True,exist_ok=False);started=time.monotonic()
    fixtures=json.loads((ROOT/'numerical_audit/fixtures/manifest.json').read_text());families=('li2','f2','nh3')
    sources={p.name:sha(p) for p in (Path(__file__),HERE/'PROTOCOL.md',HERE/'frozen_candidate.py',HERE/'exact_blocks.py')}
    write(out/'manifest.json',{'families':families,'multipliers':[[1,1],[5,4]],'methods':METHODS,'expected_evolutions':30,
       'source_sha256':sources,'fixture_manifest_sha256':sha(ROOT/'numerical_audit/fixtures/manifest.json'),
       'target_scope':'Fixed-geometry coefficient scaling of screened exact dyadic parent target; geometry-scale development cases are distinct.'})
    for name in sources:shutil.copyfile(HERE/name,out/name)
    (out/'inputs').mkdir()
    for family in families:shutil.copyfile(ROOT/'numerical_audit/fixtures'/family/fixtures[family]['tensor'],out/'inputs'/fixtures[family]['tensor'])
    prepared=[prepare(family,fixtures[family],num,den,out) for family in families for num,den in ((1,1),(5,4))]
    write(out/'ALL_CANDIDATES_FROZEN.json',{'design_hashes':{case:sha(out/f'{case}.design.json') for case,*_ in prepared},
         'seconds_before_any_approximate_evolution':time.monotonic()-started,'source_sha256':sources})
    rows=[]
    for item in prepared:rows+=run_case(item,out)
    write(out/'results.json',rows)
    comparison=[]
    for case in sorted(set(r['case'] for r in rows)):
        values={r['ordering']:r['one_minus_overlap'] for r in rows if r['case']==case};c=values['class_refined_response']
        comparison.append({'case':case,'errors':values,'candidate_over_baseline':{name:c/v if v>1e-12 else None for name,v in values.items() if name!='class_refined_response'},
                            'outcomes':{name:'tie' if abs(c-v)<=1e-12 else ('win' if c<v else 'loss') for name,v in values.items() if name!='class_refined_response'}})
    summary={'comparisons':comparison,'baselines':{name:{'outcomes':{o:sum(c['outcomes'][name]==o for c in comparison) for o in ('win','tie','loss')},
          'median_candidate_over_baseline':float(np.median([c['candidate_over_baseline'][name] for c in comparison if c['candidate_over_baseline'][name] is not None]))}
          for name in METHODS if name!='class_refined_response'}}
    write(out/'summary.json',summary)
    require(sources=={name:sha(HERE/name) for name in sources},'Source changed midrun')
    write(out/'completion.json',{'rows':len(rows),'elapsed_seconds':time.monotonic()-started,'peak_rss_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
    event(event='complete',summary=summary)

if __name__=='__main__':main()
