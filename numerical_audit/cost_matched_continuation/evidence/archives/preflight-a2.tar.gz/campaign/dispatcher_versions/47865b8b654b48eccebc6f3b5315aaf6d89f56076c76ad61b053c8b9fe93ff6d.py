"""One-job dispatcher with append-only cumulative phase and disk accounting.

--root is RUN_ROOT, containing RESOURCE_POOLS.json, jobs/, logs/, campaign/,
and scientific DATA_ROOT at data/. Guard --output remains the cumulative
RUN_ROOT, including every scientific output and failed-attempt artifact.
"""
import argparse
import datetime
import fcntl
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys

LABEL = re.compile(r'[A-Za-z0-9][A-Za-z0-9-]{0,127}\Z', re.ASCII)
DISK_SCOPE = ('cumulative RUN_ROOT including DATA_ROOT, jobs, logs, guards and '
              'dispatcher versions; not per-job output bytes')
FACTORS = {'h': 3600, 'min': 60, 's': 1, 'ms': .001,
           'us': .000001, 'µs': .000001, 'ns': .000000001}
TOKEN = re.compile(r'([0-9]+(?:\.[0-9]+)?)(h|min|ms|us|µs|ns|s)')


def cpu_value(value):
    if type(value) not in (int, float):
        return None
    try:
        return float(value) if math.isfinite(value) and value >= 0 else None
    except (OverflowError, ValueError):
        return None


def service_cpu(fields):
    value = fields.get('CPUUsageNSec', '')
    if not isinstance(value, str) or not value or not value.isascii() or not value.isdigit():
        return None
    try:
        return cpu_value(int(value)/1e9)
    except (OverflowError, ValueError):
        return None


def footer_cpu(log_contents):
    """Parse complete duration-token sequences, never a partial footer match."""
    observations = []
    for summary in re.findall(r'^CPU time consumed: (.+)$', log_contents, re.MULTILINE):
        total = 0.; end = 0; valid = True; count = 0
        for token in TOKEN.finditer(summary):
            if summary[end:token.start()].strip():
                valid = False
                break
            total += float(token[1])*FACTORS[token[2]]
            end = token.end(); count += 1
        if valid and count and not summary[end:].strip() and cpu_value(total) is not None:
            observations.append(total)
    return max(observations) if observations else None


def account_cpu(receipt, log_contents, fields, reserved_CPU_seconds, service_query_exit=0):
    """Reconcile terminal evidence; live poll samples alone remain unmeasured.

    Unknown terminal CPU consumes the entire reservation plus any observed
    overshoot. A real terminal zero is retained only with valid terminal proof.
    This pure helper neither mutates its inputs nor queries a service.
    """
    reserved = cpu_value(reserved_CPU_seconds)
    if reserved is None or reserved <= 0:
        raise ValueError('Finite positive CPU reservation required')
    final = receipt.get('final_accounting', {})
    guard = cpu_value(final.get('CPU_seconds'))
    partials = [] if guard is None else [guard]
    for sample in receipt.get('samples', []):
        text = sample.get('service', '')
        if isinstance(text, str):
            sample_fields = dict(row.split('=', 1) for row in text.splitlines() if '=' in row)
            observed = service_cpu(sample_fields)
            if observed is not None:
                partials.append(observed)
    measured = receipt.get('process_measurements', {})
    user, system = cpu_value(measured.get('user_cpu_seconds')), cpu_value(measured.get('system_cpu_seconds'))
    process = cpu_value(user+system) if user is not None and system is not None else None
    if process is not None:
        partials.append(process)
    process_terminal = process if final.get('process_CPU_timing_available') is True else None
    footer = footer_cpu(log_contents)
    service = service_cpu(fields) if type(service_query_exit) is int and service_query_exit == 0 else None
    terminal = [value for value in (process_terminal, footer, service) if value is not None]
    available = bool(terminal)
    partial = max(partials) if partials else None
    raw = max(terminal+([] if guard is None else [guard])) if available else None
    observations = [value for value in (raw, partial, None if footer is None else footer+.001) if value is not None]
    if process_terminal is not None and footer is None and service is None:
        # GNU time formats user and system CPU independently to two decimals.
        observations.append(process_terminal+.02)
        rounding, basis = .02, 'GNU time user+system only: +0.02 seconds for two rounded fields'
    elif footer is not None:
        rounding, basis = .001, 'CPU time consumed footer: +0.001 seconds on charged CPU only'
    elif service is not None:
        rounding, basis = 0., 'Successful postexit service counter; no decimal rounding allowance'
    else:
        rounding, basis = 0., 'Unknown terminal CPU: full reservation and any known partial overshoot'
    charged = max(observations+([] if available else [reserved]))
    return dict(raw_terminal_CPU_seconds=raw, terminal_CPU_measurement_available=available,
        charged_CPU_seconds=charged, guard_reported_CPU_seconds=guard, partial_CPU_seconds=partial,
        CPU_rounding_allowance_seconds=rounding, CPU_rounding_basis=basis)


def archive_dispatcher(root):
    """Preserve the exact producer before writing its PLAN; keep old versions."""
    raw = Path(__file__).read_bytes()
    actual = hashlib.sha256(raw).hexdigest()
    spelling = 'campaign/dispatcher_versions/'+actual+'.py'
    path = root/spelling
    if not path.resolve().is_relative_to(root):
        raise ValueError('Dispatcher archive escapes RUN_ROOT')
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != raw:
            raise ValueError('Existing dispatcher source version differs')
    else:
        with path.open('xb') as stream:
            stream.write(raw)
    return spelling, actual


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--phase', required=True)
    parser.add_argument('--label', required=True)
    parser.add_argument('--cpu', type=float, required=True)
    parser.add_argument('--wall', type=int, required=True)
    parser.add_argument('--cwd', type=Path, required=True)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    root = args.root.resolve(strict=True)
    data_root = (root/'data').resolve()
    if not data_root.is_relative_to(root) or data_root == root:
        raise ValueError('Scientific DATA_ROOT must remain inside cumulative RUN_ROOT')
    pools_path = root / 'RESOURCE_POOLS.json'
    pools = json.loads(pools_path.read_text())
    freeze_path = root / 'CAMPAIGN_FREEZE_A.json'
    if freeze_path.exists():
        freeze = json.loads(freeze_path.read_text())
        if digest(pools_path) != freeze['resource_pools_sha256']:
            raise ValueError('Resource pools differ from the pre-chemistry freeze')
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    if not command or LABEL.fullmatch(args.label) is None or not math.isfinite(args.cpu) or min(args.cpu, args.wall) <= 0:
        raise ValueError('Nonempty command, unique label and positive caps required')
    caps = pools['phases'][args.phase]
    if pools['guard']['path'] != 'campaign/resource_guard.py':
        raise ValueError('Canonical frozen guard path required')
    guard = (root/pools['guard']['path']).resolve(strict=True)
    if not guard.is_relative_to(root):
        raise ValueError('Guard source escapes RUN_ROOT')
    if digest(guard) != pools['guard']['sha256']:
        raise ValueError('Frozen guard changed')
    jobs = root / 'jobs'
    logs = root / 'logs'
    jobs.mkdir(exist_ok=True)
    logs.mkdir(exist_ok=True)
    with (root / 'DISPATCH.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        used_cpu = used_wall = 0.0
        for path in sorted(jobs.glob('*.PLAN.json')):
            plan = json.loads(path.read_text())
            final = path.with_name(path.name.replace('.PLAN.json', '.FINAL.json'))
            if not final.exists():
                raise RuntimeError('Unreconciled attempt blocks another launch: ' + str(path))
            result = json.loads(final.read_text())
            if plan['phase'] == args.phase:
                # Reconcile older attempts conservatively without rewriting
                # their original PLAN, FINAL, logs or receipt bytes.
                receipt_name = logs/(plan['label']+'.resources.json')
                previous_receipt = json.loads(receipt_name.read_text())
                if digest(receipt_name) != result['receipt_sha256']:
                    raise ValueError('Previous attempt receipt changed')
                previous_cpu = account_cpu(previous_receipt,
                    (logs/(plan['label']+'.log')).read_text(errors='replace'),
                    result.get('final_service_snapshot', {}), plan['attempt_CPU_seconds'],
                    result.get('final_service_query_exit', 1))
                used_cpu += max(result['charged_CPU_seconds'], previous_cpu['charged_CPU_seconds'])
                used_wall += result['absolute_guarded_wall_seconds']
        if used_cpu + args.cpu > caps['CPU_seconds'] or used_wall + args.wall > caps['wall_seconds']:
            raise RuntimeError('Attempt does not fit remaining frozen phase allowance')
        plan_path = jobs / (args.label + '.PLAN.json')
        dispatcher_path, dispatcher_sha = archive_dispatcher(root)
        save(plan_path, dict(phase=args.phase, label=args.label,
            attempt_CPU_seconds=args.cpu, attempt_wall_seconds=args.wall,
            prior_phase_CPU_seconds=used_cpu, prior_phase_wall_seconds=used_wall,
            cwd=str(args.cwd.resolve()), command=command,
            pools_sha256=digest(pools_path), dispatcher_sha256=dispatcher_sha,
            dispatcher_archive_path=dispatcher_path,
            disk_accounting_scope=DISK_SCOPE, disk_accounting_root=str(root), data_root=str(data_root),
            started_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        run = subprocess.run([sys.executable, str(guard), '--label', args.label,
            '--logs', str(logs), '--cpu-seconds', str(args.cpu),
            '--wall-seconds', str(args.wall), '--disk-mib', str(pools['output_MiB']),
            '--output', str(root), '--', *command], cwd=args.cwd)
        receipt_path = logs / (args.label + '.resources.json')
        if not receipt_path.is_file():
            raise RuntimeError('Missing receipt; keep reserved attempt unreconciled')
        receipt = json.loads(receipt_path.read_text())
        log = logs / (args.label + '.log')
        # Failed services commonly remain available after systemd-run exits.
        try:
            snapshot = subprocess.run(['systemctl', '--user', 'show', receipt['unit'],
                '-p', 'CPUUsageNSec', '-p', 'MemoryPeak', '-p', 'Result',
                '-p', 'ActiveState', '-p', 'SubState'], text=True, capture_output=True)
            fields = dict(row.split('=', 1) for row in snapshot.stdout.splitlines() if '=' in row)
            query_exit = snapshot.returncode
        except OSError as error:
            fields = {'query_error': str(error)}
            query_exit = 127
        accounting = account_cpu(receipt, log.read_text(errors='replace'), fields, args.cpu, query_exit)
        save(jobs / (args.label + '.FINAL.json'), dict(phase=args.phase, label=args.label,
            exit_code=run.returncode, receipt_sha256=digest(receipt_path),
            **accounting, absolute_guarded_wall_seconds=receipt['elapsed'],
            dispatcher_sha256=dispatcher_sha, dispatcher_archive_path=dispatcher_path,
            disk_accounting_scope=DISK_SCOPE, disk_accounting_root=str(root), data_root=str(data_root),
            final_service_snapshot=fields, final_service_query_exit=query_exit,
            accounting_scope='Terminal process timing/footer/postexit service required; otherwise full reservation plus any partial overshoot; footer +.001 or process-only +.02 rounding affects conservative charge only',
            completed_UTC=datetime.datetime.now(datetime.timezone.utc).isoformat()))
        return run.returncode


if __name__ == '__main__':
    raise SystemExit(main())
