"""Deterministic metadata-only refusal trace; no worker/service is launched."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('cmc_controller_under_test', Path(__file__).with_name('run_panel.py'))
controller = importlib.util.module_from_spec(spec)
spec.loader.exec_module(controller)


class ParentRefusalTrace(unittest.TestCase):
    def test_all_parent_outcomes_precede_atomic_freeze_and_stop(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            data = root/'data'; data.mkdir()
            (data/'INPUT_PROTOCOL_FROZEN.json').write_text(json.dumps(dict(
                mode='main', registry=dict(cases=[dict(case='A'), dict(case='B')]))))
            workers, finalized, freezes = [], [], []
            def guarded(*args, **kwargs):
                command = list(map(str, args[5]))
                self.assertEqual(command[command.index('--arm')+1], 'parent')
                workers.append(command[command.index('--case')+1])
                return 0
            def call(command, **kwargs):
                command = list(map(str, command))
                if '--finalize' in command:
                    case = command[command.index('--case')+1]
                    rep = int(command[command.index('--repetition')+1])
                    target = data/'parents'/case/('rep'+str(rep)+'.json')
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_text(json.dumps(dict(eligible=(case, rep) != ('A', 1))))
                    finalized.append((case, rep))
                else:
                    self.assertEqual(command[-2:], ['--freeze', 'parents'])
                    self.assertEqual(finalized, [('A', 1), ('A', 2), ('B', 1), ('B', 2)])
                    freezes.append('parents')
                return 0
            with patch.object(controller, 'guarded', side_effect=guarded), patch.object(controller, 'call', side_effect=call):
                with self.assertRaisesRegex(RuntimeError, 'all parent outcomes frozen'):
                    controller.run(root, 'construct')
            self.assertEqual(workers, ['A', 'A', 'B', 'B'])
            self.assertEqual(freezes, ['parents'])


if __name__ == '__main__':
    unittest.main()
