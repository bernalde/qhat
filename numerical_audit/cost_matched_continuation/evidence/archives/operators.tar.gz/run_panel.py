"""Root-only serial execution of a source-frozen experiment; no GitHub writes."""
import argparse
import json
import math
from pathlib import Path
import subprocess
import sys

PY = '/home/bernalde/repos/fermionic-ordering-research/benchmark-venv-py312/bin/python'
JL = '/home/bernalde/.julia/juliaup/julia-1.10.11+0.x64.linux.gnu/bin/julia'
WT = Path('/tmp/qhat-cost-matched-continuation-2026-10-29/worktree')
STUDY = WT/'numerical_audit/cost_matched_continuation'
DISPATCH = Path(__file__).with_name('run_guarded_job.py')


def call(command, check=True):
    print('EXECUTING', ' '.join(map(str, command)), flush=True)
    return subprocess.run(list(map(str, command)), cwd=WT, check=check).returncode


def guarded(campaign, phase, label, cpu, wall, command, check=True):
    code = call([PY, DISPATCH, '--root', campaign, '--phase', phase, '--label', label,
        '--cpu', cpu, '--wall', wall, '--cwd', WT, '--', *command], check=False)
    if code and check:
        raise RuntimeError('Retained failed job: '+label)
    return code


def run(campaign, stage):
    data = campaign/'data'
    frozen = json.loads((data/'INPUT_PROTOCOL_FROZEN.json').read_text())
    preflight = frozen.get('mode') == 'preflight'
    cases = [frozen['configuration']['preflight']['case']] if preflight else [v['case'] for v in frozen['registry']['cases']]
    reps = 1 if preflight else 2
    prefix = 'pf' if preflight else 'main'
    if stage in ('construct', 'all'):
        refused_parents = []
        for number, case in enumerate(cases, 1):
            for rep in range(1, reps+1):
                label = prefix+'-parent-c'+str(number)+'-r'+str(rep)+'-a1'
                raw = data/'workers'/case/('rep'+str(rep)+'-parent.json')
                guarded(campaign, 'constructors', label, 8, 40, [PY, STUDY/'construct.py',
                    '--root', data, '--worker', '--case', case, '--repetition', rep,
                    '--arm', 'parent', '--cpu-cap', 8, '--wall-cap', 40, '--raw', raw], check=False)
                call([PY, STUDY/'construct.py', '--root', data, '--finalize', '--case', case,
                    '--repetition', rep, '--arm', 'parent', '--raw', raw, '--campaign', campaign, '--label', label])
                parent = json.loads((data/'parents'/case/('rep'+str(rep)+'.json')).read_text())
                if not parent['eligible']:
                    refused_parents.append((case, rep))
        call([PY, STUDY/'construct.py', '--root', data, '--freeze', 'parents'])
        if refused_parents:
            raise RuntimeError('Parent refused; all parent outcomes frozen, no replacement: '+repr(refused_parents))
        # Alternate arm execution by case/repetition/budget; both consume the
        # same parent, and no physical errors are available during construction.
        for number, case in enumerate(cases, 1):
            for rep in range(1, reps+1):
                parent = json.loads((data/'parents'/case/('rep'+str(rep)+'.json')).read_text())
                for budget in (32, 64):
                    arms = ('full', 'window') if (number+rep+budget//32) % 2 else ('window', 'full')
                    for arm in arms:
                        cpu = budget-parent['costs']['total']['charged_CPU_seconds']
                        wall = math.floor(5*budget-parent['costs']['total']['wall_seconds'])
                        label = prefix+'-'+arm+'-c'+str(number)+'-r'+str(rep)+'-b'+str(budget)+'-a1'
                        raw = data/'workers'/case/('rep'+str(rep)+'-'+arm+'-B'+str(budget)+'.json')
                        common = ['--root', data, '--case', case, '--repetition', rep, '--arm', arm,
                                  '--budget', budget, '--raw', raw]
                        guarded(campaign, 'constructors', label, cpu, wall,
                            [PY, STUDY/'construct.py', '--worker', *common, '--cpu-cap', cpu,
                             '--wall-cap', wall, '--julia-executable', JL], check=False)
                        call([PY, STUDY/'construct.py', '--finalize', *common, '--campaign', campaign, '--label', label])
        call([PY, STUDY/'construct.py', '--root', data, '--freeze', 'continuations'])
        guarded(campaign, 'packaging', prefix+'-panels-a1', 15, 90,
                [PY, STUDY/'panels.py', '--root', data])
    if stage in ('physical', 'all'):
        for folder in ('physical', 'objective', 'independent'):
            (data/folder).mkdir(exist_ok=True)
        for number, case in enumerate(cases, 1):
            model, panel = data/'inputs'/case/'model.toml', data/'panels'/case/'candidates.toml'
            guarded(campaign, 'physics', prefix+'-physical-c'+str(number)+'-a1', 100, 500,
                [JL, '--startup-file=no', '--threads=1', STUDY/'physical.jl', model, panel, data/'physical'/case])
            guarded(campaign, 'objective', prefix+'-objective-c'+str(number)+'-a1', 120, 600,
                [JL, '--startup-file=no', '--threads=1', STUDY/'objective.jl', model, panel, data/'objective'/case])
            guarded(campaign, 'independent', prefix+'-independent-c'+str(number)+'-a1', 200, 1000,
                [JL, '--startup-file=no', '--threads=1', STUDY/'verify.jl', model, panel,
                 data/'physical'/case, data/'independent'/case])
        call([PY, STUDY/'ledger.py', '--root', data, '--campaign', campaign])
        guarded(campaign, 'packaging', prefix+'-analysis-a1', 20, 120,
                [PY, STUDY/'analyze.py', '--root', data, '--output', data/'ANALYSIS.json'])


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign', type=Path, required=True)
    parser.add_argument('--stage', choices=('construct', 'physical', 'all'), default='all')
    args = parser.parse_args()
    run(args.campaign, args.stage)
